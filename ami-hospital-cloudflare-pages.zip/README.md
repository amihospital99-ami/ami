# Ami Hospital - Cloudflare Pages Deployment Package

This ZIP package is pre-configured and ready to deploy directly to Cloudflare Pages.

## Option 1: Direct Upload (No Git Required - Fastest)
1. Log in to the Cloudflare Dashboard: https://dash.cloudflare.com/
2. Go to **Workers & Pages** > **Create application** > **Pages** tab.
3. Select **Upload assets**.
4. Enter a project name (e.g. `ami-hospital`).
5. Drag and drop this extracted folder (or upload the zip).
6. Click **Deploy site**.
Your site will instantly be live at `https://ami-hospital.pages.dev`!

## Option 2: Deploy via Wrangler CLI
```bash
npm install -g wrangler
wrangler pages deploy dist --project-name=ami-hospital
```

## Included Files:
- `index.html`: The optimized Ami Hospital landing page application.
- `assets/`: Bundled JavaScript and Tailwind CSS assets.
- `_headers`: Pre-configured security and caching HTTP response headers for Cloudflare edge CDN.
- `_routes.json`: Cloudflare routing rules.
